package models.users;

import java.util.*;
import javax.persistence.*;
import java.text.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;
import java.util.Calendar;
import models.shopping.*;

import models.users.Address;

@Entity

@DiscriminatorValue("customer")

public class Customer extends User{
	
   

    private String creditCard;
    private String contactNum;
    @Temporal(TemporalType.DATE)
    private Calendar dob;

    @OneToOne(mappedBy="customer", cascade = CascadeType.ALL)
    private Basket basket;

    @OneToOne(mappedBy="customer", cascade = CascadeType.ALL)
    private Fav fav;


    @OneToMany(mappedBy="customer", cascade = CascadeType.ALL)
    private List<ShopOrder> orders;

    @OneToOne
    private Address address;
	
	public Customer(String email, String role, String name, String password, Address address, String creditCard, Calendar dob, String contactNum)
	{
		super(email, role, name, password);
        this.address = address;
		this.creditCard = creditCard;
	}



    public String getContactNum(){
        return contactNum;
    }
     public void setContactNum(String contactNum){
     this.contactNum = contactNum;
     }
  
    public void setDob(Calendar dob){
        this.dob = dob;
    }
    public Calendar getDob(){
        return dob;
    }

    public Address getAddress() { 
        return address; 
    } 
    public void setAddress(Address address) { 
        this.address = address; 
    } 

    public String getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(String creditCard) {
        this.creditCard = creditCard;
    }
    public Basket getBasket() {
        return basket;
    }

    public void setBasket(Basket basket) {
        this.basket = basket;
    }
    public Fav getFav() {
        return fav;
    }

    public void setFav(Fav fav) {
        this.fav = fav;
    }

    public List<ShopOrder> getOrders() {
        return orders;
    }

    public void setOrders(List<ShopOrder> orders) {
        this.orders = orders;
    }

    public static Customer getCustomerById(String id) {
        if (id == null) {
            return null;
        }
        else {
            return finder.byId(id);
        }
    } 

    public static Finder<String, Customer> finder = new Finder<String, Customer>(Customer.class);


    
}