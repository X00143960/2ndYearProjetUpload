package models.users;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import models.users.Customer;


@Entity
public class Address extends Model {

    @Id
    private Long addId;
    private String addressLine;
    private String county;
    private String postCode;

    public Address() {

    }

    public Address(String addressLine, String county, String postCode) {
        this.addressLine = addressLine;
        this.county = county;
        this.postCode = postCode;
    }


    
    // Generic query helper for entity Address with id of type Long
    public static final Finder<Long, Address> find = new Finder<>(Address.class);

    // Return an array list of all Address objects
    public static final List<Address> findAll() {
        return Address.find.all();
    }


    public Long getAddressId() {
        return this.addId;
    }

    public void setAddressId(Long addressId) {
        this.addId = addressId;
    }

    public String getAddressLine() {
        return this.addressLine;
    }

    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }

    public String getCounty() {
        return this.county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getpostCode() {
        return this.postCode;
    }

    public void setpostCode(String postCode) {
        this.postCode = postCode;
    }


}