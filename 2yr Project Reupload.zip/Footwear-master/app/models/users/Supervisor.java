package models.users;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;
import models.shopping.*;


@Entity
@DiscriminatorValue("supervisor")


public class Supervisor extends User {
	
private int numReturns;
@OneToMany(mappedBy="supervisor", cascade = CascadeType.ALL)
private List<ShopOrder> orders;
	public Supervisor() {

	}
	public Supervisor(String email, String role, String name, String password, int numReturns)
	{
		super(email, role, name, password);
		this.numReturns = numReturns;
	}

	public int getNumReturns() {
		return numReturns;
	}

	public void setNumReturns(int numReturns) {
		this.numReturns = numReturns;
	}
	public List<ShopOrder> getOrders() {
        return orders;
    }

    public void setOrders(List<ShopOrder> orders) {
        this.orders = orders;
    }

}