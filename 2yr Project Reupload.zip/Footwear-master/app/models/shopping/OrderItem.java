package models.shopping;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import models.shoes.*;
import models.users.*;

@Entity
public class OrderItem extends Model {

    @Id
    private Long id;

    @ManyToOne
    private ShopOrder order;
    
    @ManyToOne
    private Basket basket;
    
    @ManyToOne
    private Fav fav;
    
    
    @ManyToOne
    private Footwear footwear;
    
    private int quantity;
    private double price;

  
    public  OrderItem() {
    }
    
    public OrderItem(Footwear f) {
            footwear = f;
            quantity = 1;
            price = f.getPrice();
    }
       
      // Increment quantity
      public void increaseQty() {
        quantity += 1;
    }
     // Decrement quantity
public void decreaseQty() {
    quantity -= 1;
}

    
    public double getItemTotal() {
        return this.price * this.quantity;
    }
	

    public static Finder<Long,OrderItem> find = new Finder<Long,OrderItem>(OrderItem.class);


    public static List<OrderItem> findAll() {
        return OrderItem.find.all();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ShopOrder getOrder() {
        return order;
    }

    public void setOrder(ShopOrder order) {
        this.order = order;
    }

    public Basket getBasket() {
        return basket;
    }

    public void setBasket(Basket basket) {
        this.basket = basket;
    }
    public Fav getFav() {
        return fav;
    }

    public void setFav(Fav fav) {
        this.fav = fav;
    }

    public Footwear getFootwear() {
        return footwear;
    }

    public void setFootwear(Footwear footwear) {
        this.footwear = footwear;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

}
