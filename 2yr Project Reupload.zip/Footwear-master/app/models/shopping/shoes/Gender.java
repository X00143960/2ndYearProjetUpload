
package models.shoes;


import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;






  
@Entity

public class Gender extends Model {

    @Id
    private Long id;
    @Constraints.Required
    private String genderV;

    @ManyToMany(cascade = CascadeType.ALL)
    private List<Footwear> footwear;




public Gender(){

}

public static List<Gender> findAll() {
    return Gender.find.query().where().orderBy("id asc").findList();
}
    public Gender(Long id, String genderV, List<Footwear> footwear) {
        this.id = id;
        this.genderV= genderV;
        this.footwear = footwear;
       
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGenderV() {
        return genderV;
    }

    public void setGenderV(String genderv) {
        this.genderV = genderV;
    }

 

    public void setFootwear( List<Footwear>footwear){
        this.footwear = footwear;
    }
    public List<Footwear> getFootwear(){
        return footwear;
    }
   

    public static Finder<Long, Gender> find = new Finder<Long, Gender>(Gender.class);


  





    public static Map<String,String> options() {
        LinkedHashMap<String,String> options = new LinkedHashMap<>();



        for(Gender g: Gender.findAll()) {
            options.put(Long.toString(g.getId()), g.getGenderV());

        }
        return options;
    }
    
}

