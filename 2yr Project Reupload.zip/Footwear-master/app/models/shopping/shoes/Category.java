package models.shoes;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Category extends Model {
    @Id
    private Long id;
    
    @Constraints.Required
    private String name;

    @ManyToMany(cascade = CascadeType.ALL)
    private List<Footwear> footwear;

    public Category() {
    }

    public Category(Long id, String name, List<Footwear> footwear) {
        this.id = id;
        this.name = name;
        this.footwear = footwear;
   
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

 

    public void setFootwear( List<Footwear>footwear){
        this.footwear = footwear;
    }
    public List<Footwear> getFootwear(){
        return footwear;
    }
    public static Finder<Long, Category> find = new Finder<Long, Category>(Category.class);

    public static List<Category> findAll() {
        return Category.find.query().where().orderBy("name asc").findList();
    }

    public static Map<String, String> options() {
        LinkedHashMap<String, String> options = new LinkedHashMap();

        for (Category c: Category.findAll()) {
            options.put(c.getId().toString(), c.getName());
        }
        
        return options;
    }
       
            public static boolean inCategory(Long category, Long footwear) {
                return find.query().where()
                    .eq("footwear.id", footwear)
                    .eq("id", category)
                    .findCount() > 0;
            }
            

}