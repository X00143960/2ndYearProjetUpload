package models.shoes;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;
import models.shopping.*;
@Entity
public class Footwear extends Model {
    
        
        @Id
        private Long id;
        @Constraints.Required
        private String name;
        @ManyToMany(cascade = CascadeType.ALL,mappedBy="footwear")
        public List<Category> categories;
        @ManyToMany(cascade = CascadeType.ALL,mappedBy="footwear")
        public List<Size> sizes;
        @ManyToMany(cascade = CascadeType.ALL,mappedBy="footwear")
        public List<Gender> genders;
        @ManyToMany(cascade = CascadeType.ALL,mappedBy="footwear")
        public List<Colour> colours;
        @ManyToMany(cascade = CascadeType.ALL,mappedBy="footwear")
        public List<Fit> fitOfShoe;
        @ManyToMany(cascade = CascadeType.ALL,mappedBy="footwear")
        public List<Payment> creditCard;
        @ManyToMany(cascade = CascadeType.ALL,mappedBy="footwear")
        public List<TrueFit> trues;
        @Constraints.Required
        private String description; 
        @Constraints.Required
        private int stock; 
        @Constraints.Required
        private double price; 
    
   
    
      

           public Footwear() {
        }
 
        public Footwear(Long id, String name, String description, int stock, double price) {
            this.id = id;
            this.name = name;
            this.description = description;
            this.stock = stock;
            this.price = price;
           
         
            
        }
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }

        public List<Category> getCategories() {
            return categories;
        }

        public Long getId() {
            return id;
        }
        public void setId(Long id) {
            this.id = id;
        }
           
        public List<Long> getFitSelect(){
            return fitSelect;
        }
        public void setFitSelect(List<Long> fitSelect){
            this.fitSelect = fitSelect;
        }
        public List<Long> getTrueSelect(){
            return trueSelect;
        }
        public void setTrueSelect(List<Long> trueSelect){
            this.trueSelect = trueSelect;
        }
        public List<Long> getPaySelect(){
            return paySelect;
        }
        public void setPaySelect(List<Long> paySelect){
            this.paySelect = paySelect;
        }
        
        public List<Long> getCatSelect(){
            return catSelect;
        }
        public void setCatSelect(List<Long> catSelect){
            this.catSelect = catSelect;
        }
        public List<Long> getGenSelect(){
            return genSelect;
        }
        public void setGenSelect(List<Long> genSelect){
            this.genSelect = genSelect;
        }
        public List<Long> getSizeSelect(){
            return sizeSelect;
        }
        public void setSizeSelect(List<Long> sizeSelect){
            this.sizeSelect = sizeSelect;
        }
        public List<Long> getColourSelect(){
            return colourSelect;
        }
        public void setColourSelect(List<Long> colourSelect){
            this.colourSelect = colourSelect;
        }
        public String getDescription() { 
            return description; 
        } 
        public void setDescription(String description) { 
            this.description = description; 
        } 
        public int getStock() { 
            return stock; 
        } 
        public void setStock(int stock) { 
            this.stock = stock; 
        } 
        public double getPrice() { 
            return price; 
        } 
        public void setPrice(double price) { 
            this.price = price; 
        } 
    
    
    
    
        public void increaseStock(int qty) {
            this.stock += qty;
        }
      
    
    
  
        public static final Finder<Long, Footwear> find = new Finder<>(Footwear.class);
     
        private List<Long> catSelect = new ArrayList<Long>();
        private List<Long> sizeSelect = new ArrayList<Long>();
        private List<Long> genSelect = new ArrayList<Long>();
        private List<Long> colourSelect = new ArrayList<Long>();
        private List<Long> fitSelect = new ArrayList<Long>();
        private List<Long> paySelect = new ArrayList<Long>();
        private List<Long> trueSelect = new ArrayList<Long>();

        public static final List<Footwear> findAll() { 
            
            return Footwear.find.all();
}

    public static List<Footwear> findAll(String filter) {
        return Footwear.find.query().where()
                        .ilike("name", "%" + filter + "%")
                        .orderBy("name asc")
                        .findList();
    }
    
    public List <Size>getSize(){
    
    return sizes;
    
    }
    public List <TrueFit>getTrueFit(){
    
        return trues;
        
        }
   
    public List<Gender> getGender(){
        
        return genders;
        
        }
        public List<Colour> getColourNames(){
            
            return colours;
            
            }

            public List<Fit> getFitNames(){
                
                return fitOfShoe;
                
                }
               
                public boolean decrementStock(){
                    boolean allowed =true;
                    if ((stock-1) < 0){
                        allowed = false;
                    }else{
                        stock = stock-1;
                    }
                    return allowed;
                }
                public void incrementStock(int q){          
                    stock = stock +q;
                }
    // Filter Footwear name 
    public static List<Footwear> findFilter(Long catID, String filter) {
        return Footwear.find.query().where()
                        .eq("categories.id", catID)
                        .ilike("name", "%" + filter + "%")
                        .orderBy("name asc")
                        .findList();
                    }

    public List<String> getShoeSizes(){
    
    List<String> sizes = new ArrayList<>();
    
    if(getSize().size() >0){
    
    for(int i = 0; i < getSize().size(); i++){
    
    sizes.add(Double.toString(getSize().get(i).getSizeOfShoe()));
}

} else {

sizes.add("no sizes available at moment");

}

return sizes;

}  

public List<String> getGenderTypes(){
    List<String> gender = new ArrayList<>();
    
    if(getGender().size() >0){
    
    for(int i = 0; i < getGender().size(); i++){
    
    gender.add((getGender().get(i).getGenderV()));
}

} else {

gender.add("no genders available at moment");

}

return gender;

}   


 
public List<String> getColourName(){
    
    List<String> col = new ArrayList<>();
    
    if(getColourNames().size() >0){
    
    for(int i = 0; i < getColourNames().size(); i++){

    col.add(getColourNames().get(i).getColourOfShoe());
}

} else {

col.add("no colours available at moment");

}

return col;

}  
    



  

public List<String> getFitName(){
    
    List<String> fitSize = new ArrayList<>();
    
    if(getFitNames().size() >0){
    
    for(int i = 0; i < getFitNames().size(); i++){

    fitSize.add(getFitNames().get(i).getFitOfShoe());
}

} else {

fitSize.add("no fits available at moment");

}

return fitSize;

} 



public List<String> getTrueFits(){
    
    List<String> t = new ArrayList<>();
    
    if(getTrueFit().size() >0){
    
    for(int i = 0; i < getTrueFit().size(); i++){

    t.add(getTrueFit().get(i).getNewShoe());
}

} else {

t.add("no fits available at moment");

}

return t;

} 

}
