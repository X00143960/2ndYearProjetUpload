package models.shoes;
import java.util.Scanner;
import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;
  
@Entity
 public class TrueFit extends Model{
    @Id
private Long id; 
public double size;

@ManyToMany(cascade = CascadeType.ALL)
private List<Footwear> footwear;
public String fit;

public String newShoe;
public String oldShoe;

public TrueFit(){

}
public TrueFit(double size, String fit,String newShoe, String oldShoe, Long id, List<Footwear> footwear){
    this.fit = fit;
    this.size = size;
    this.newShoe = newShoe;
    this.oldShoe = oldShoe;
    this.id = id;
    this.footwear = footwear;
}
public static List<TrueFit> findAll() {
    return TrueFit.find.query().where().orderBy("id asc").findList();
}
public Long getId() {
    return id;
}

public void setId(Long id) {
    this.id = id;
}

public String getOldShoe(){
    return oldShoe;
}
public void setOldShoe(String oldShoe){
    this.oldShoe = oldShoe;
}

public String getNewShoe(){
    return newShoe;
}
public void setNewShoe(String newShoe){
    this.newShoe = newShoe;
}

public String getFit(){
    return fit;
}

public void setFit(String fit){
    this.fit = fit;
}
public double getSize(){
    return size;
}

public void setSize(double size){
    this.size = size;
}
public void setFootwear( List<Footwear>footwear){
    this.footwear = footwear;
}
public List<Footwear> getFootwear(){
    return footwear;
}

public static Finder<Long, TrueFit> find = new Finder<>(TrueFit.class);


public static Map<String,String> options() {
    LinkedHashMap<String,String> options = new LinkedHashMap<>();



    for(TrueFit t: TrueFit.findAll()) {
        options.put(Long.toString(t.getId()), t.getOldShoe());

    }
    return options;
}

public  double checkSize(){
    // Scanner in = new Scanner(System.in);
    // System.out.println("Enter choice");
    //  String shoe = in.nextLine();
   String shoe = " ";
   double sizer = 0;
    switch(shoe){
        case "heels":
            if(oldShoe.equals("heels")){
                sizer= getSize();

                setSize(sizer);
            }if(oldShoe.equals("sports")){
                sizer= getSize();
                
                                setSize(sizer);
            }  if(oldShoe.equals("boots")){
                sizer= getSize() +0.5;
                
                                setSize(sizer);
            }
            if(oldShoe.equals("workwear")){
                sizer= getSize() +0.5;
                
                                setSize(sizer);
            }
            break;
            
        case "sports": 
              if(oldShoe.equals("heels")){
                size = size -1;
            }if(oldShoe.equals("sports")){
                size = size;
            }  if(oldShoe.equals("boots")){
                size = size -0.5;
            }
            if(oldShoe.equals("workwear")){
                size = size -0.5;
            }
            break;
        case "work wear":
            if(oldShoe.equals("heels")){
                size = size;
            }if(oldShoe.equals("sports")){
                size = size + 1;
            }  if(oldShoe.equals("boots")){
                size = size =0.5;
            }
            if(oldShoe.equals("workwear")){
                size = size;
            }
            break;
        case "boots":
              if(oldShoe.equals("heels")){
                size = size;
            }if(oldShoe.equals("sports")){
                size = size - 1;
            }  if(oldShoe.equals("boots")){
                size = size;
            }
            if(oldShoe.equals("workwear")){
                size = size - 0.5;
            }
            break;
    }
    // System.out.println("Size is" +size);
    return sizer;
}


public static Map<String,String> optionss() {
    LinkedHashMap<String,String> optionss = new LinkedHashMap<>();



    for(TrueFit t: TrueFit.findAll()) {
        optionss.put(Long.toString(t.getId()), Double.toString(t.getSize()));

    }
    return optionss;
}

public static Map<String,String> option() {
    LinkedHashMap<String,String> option = new LinkedHashMap<>();



    for(TrueFit t: TrueFit.findAll()) {
        option.put(Long.toString(t.getId()), t.getNewShoe());

    }
    return option;
}


}
