package controllers;

import play.mvc.*;
import controllers.security.*;
import models.users.*;
import models.users.Customer; 
import play.mvc.*;
import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import java.time.*;
import models.shopping.*;
import models.users.*;
import models.shoes.*;
import views.html.*;
import models.shoes.Footwear;

 
    
    
    
    
    public class ProductController extends Controller {
    
      
        
        private FormFactory formFactory;
        private Environment e;
        
        @Inject
        public ProductController(FormFactory f,Environment env) {
            this.formFactory = f;
            this.e = env;
            }
       
        @Transactional
        public User getCurrentUser() {
            User u = User.getUserById(session().get("email"));
            return u;
        }

        @Transactional
        public Customer getCurrentCustomer(){
            Customer c = Customer.getCustomerById(session().get("email"));
            return c;
        }

        public Result products() {
            return redirect(routes.ProductController.listFootwear(0,""));
        }
    
        @Transactional
        public Result listFootwear(Long cat, String filter){
            List<Category> categories = Category.findAll();
            List<Footwear> footwear = new ArrayList<Footwear>();
            List<Gender> genders = new ArrayList<Gender>();
            List<Size> sizes = new ArrayList<Size>();
            List<Colour> colours = new ArrayList<Colour>();
            List<Fit> fitSize = new ArrayList<Fit>();
            if (cat ==0) {
                footwear = Footwear.findAll(filter);
            }
         else {
         footwear = Footwear.findFilter(cat, filter);
           }


          return ok(listFootwear.render(e,footwear, categories,genders,colours,fitSize, sizes ,getCurrentUser(),cat,filter));

        }

        public Result footwearDetails(Long id) {
            Footwear f;
            f = Footwear.find.byId(id);
            return ok(footwearDetails.render(f,User.getUserById(session().get("email")),e));
        }
    
        
        public Result index(){
            return ok(index.render(User.getUserById(session().get("email"))));
        }
      

        public Result sizeChart(){
            return ok(sizeChart.render(User.getUserById(session().get("email"))));
        }


        public Result listColours(){
            List<Colour> colours = new ArrayList<Colour>();
           // colour = Colour.findAll();
            return ok(listColours.render(e, colours,getCurrentUser()));
        }

        



// @With(CheckIfAdmin.class)
        public Result returnOrder(long id) {
            ShopOrder order = ShopOrder.find.byId(id);
     if (order == null) {
                flash("success", "Order Order not found");
                return redirect(routes.ShoppingController.viewOrders());
            }
       
          
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime orderTime = LocalDateTime.ofInstant(order.getOrderDate().toInstant(), ZoneId.systemDefault());
            
    
            if (orderTime.getYear() == now.getYear()) {
                if (orderTime.getMonthValue() == now.getMonthValue()) {
                    if (now.getDayOfYear() - orderTime.getDayOfYear() <=30) {
                   
                            order.delete();
                            flash("success", "Order Returned");
                            return redirect(routes.ShoppingController.viewOrders());
                        } 
                    }
                }
            
    
            flash("success", "Order is too late to be Returned");
            return redirect(routes.ShoppingController.viewOrders());
        }
    
        public Result listPayment(){
            List<Payment> payment = new ArrayList<Payment>();
           // colour = Colour.findAll();
            return ok(listPayment.render(e, payment,getCurrentUser()));
        }
   
        public Result news(){
            return ok(news.render(User.getUserById(session().get("email"))));
        }



    }